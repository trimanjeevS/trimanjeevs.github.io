# Power BI validation and model design

The project contains three native report pages, six import tables, six single-direction relationships and 20 explicit DAX measures. The report definition passed Microsoft Power BI Report Authoring CLI 0.1.4 checks with **zero errors and zero warnings**. These are file, schema, visual-role and formatting checks; they do not execute the Power BI engine.

Native refresh, DAX execution, visual rendering and interactions remain **pending Power BI Desktop on Windows**. There is no preloaded model cache. First refresh loads the embedded snapshot without file paths, credentials or network queries.

## Model design

| Dimension | Sales fact | Receivables fact |
|---|---|---|
| Calendar | Date | No relationship |
| Products | ProductID | No relationship |
| Customers | CustomerID | CustomerID |
| Channels | Channel | Channel |

Sales contains one row per accepted invoice line. Receivables contains one row per open invoice at 31 December 2025. Only the dimension side filters the fact side. There are no fact-to-fact or bidirectional relationships.

Sales measures explicitly compare 2025 with 2024. Month selections apply to both years. Gross margin divides aggregated gross profit by aggregated revenue. Product and account shares use the selected dimension population. Average unit price includes product and discount mix.

Receivables measures sum the fixed snapshot. Payments after the cutoff remain in the original ledger but do not reduce snapshot balances. Current includes invoices due on the cutoff date. The final bucket starts at 91 days. Invoice aging cannot be filtered by product because no balance-allocation rule is assumed.

## Windows verification procedure

1. Open `Northline Commerce.pbip`, refresh, and check all three pages for errors, missing visuals, clipping or scrolling that obscures required values. Review on a typical laptop display at Fit to page.
2. Clear all selections. Reconcile full-year and receivables totals to the root README, including revenue of $1,402,310.67, gross profit of $589,034.50 and AR of $167,743.96.
3. Select January on Commercial overview. Revenue 2025 must be $110,785.51; Revenue 2024 must be $93,261.69. Clear the month; select Direct. Revenue 2025 must be $266,049.29 and gross margin approximately 48.1270%.
4. On Margin and contribution, confirm chronological month sorting, product/category selection, account selection and contribution totals. Clear selections before comparing with full-year figures. Table rows should be scrollable and headers readable.
5. On Receivables, confirm 64 open invoices; overdue $68,979.21; 91+ days $5,836.65. Check aging is ordered Current, 1–30, 31–60, 61–90, 91+.
6. Select Marketplace or Direct: overdue must be blank or zero. These channels have only current snapshot balances. Clear selections, choose Wholesale, and inspect its collection queue and invoice detail. Verify a sales-page month or category selection does not change this page's fixed snapshot.
7. Confirm the eight boundary invoices INV01573–INV01580 show 0, 1, 30, 31, 60, 61, 90 and 91 days past due respectively. Each has $330 outstanding after $110 paid through the cutoff.
8. Save the tested project and record Desktop version, review date and reviewer. Export native screenshots/PDF only after this check. Do not replace the standalone analytical PDF with an unreviewed export.

## Updating data

Close Desktop. Rebuild and independently audit the sibling SQL Analysis package. Run `python update_snapshot.py`; the updater validates the import schema and fixed reporting dates before replacing the embedded data. Reopen and refresh Desktop, then repeat the checks. The static analytical PDF does not update automatically.

## Format references

- [Microsoft: Power BI Desktop projects](https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-overview)
- [Microsoft: semantic model project files](https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-dataset)
- [Microsoft: report project files](https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-report)
- [Microsoft: report authoring tooling](https://github.com/microsoft/skills-for-fabric/tree/main/skills/powerbi-report-authoring)

The packaged validation records describe automated/static checks only. They are not evidence of a completed Windows review.
