"""Re-embed the reconciled SQL export; uses only the Python standard library.

Run after SQL Analysis/run.py, with Power BI Desktop closed. This updates
model data, not DAX, report layout, or the static analytical PDF.
"""
import base64
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path


def main():
    root = Path(__file__).resolve().parent
    source = root.parent / 'SQL Analysis/outputs/model_data.json'
    target = root / 'Northline Commerce.SemanticModel/model.bim'
    document = json.loads(source.read_text(encoding='utf-8'))
    tables = document['tables']
    model = json.loads(target.read_text(encoding='utf-8'))
    expected = {t['name'] for t in model['model']['tables']}
    if set(tables) != expected:
        raise ValueError('Source table names do not match the semantic model.')
    for table in model['model']['tables']:
        name = table['name']
        rows = tables[name]
        columns = {c['name']: c['dataType'] for c in table['columns']}
        if not rows:
            raise ValueError(f'{name}: empty tables need a separately reviewed schema update.')
        for i, row in enumerate(rows, 1):
            if set(row) != set(columns):
                raise ValueError(f'{name} row {i}: unexpected or missing columns.')
            for column, typ in columns.items():
                value = row[column]
                if typ == 'string' and not isinstance(value, str):
                    raise ValueError(f'{name}.{column}: expected text.')
                if typ == 'dateTime':
                    dt.date.fromisoformat(value)
                if typ in {'int64', 'decimal'}:
                    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                        raise ValueError(f'{name}.{column}: expected a finite number.')
                    if typ == 'int64' and int(value) != value:
                        raise ValueError(f'{name}.{column}: expected an integer.')
        encoded = base64.b64encode(json.dumps(rows, separators=(',', ':')).encode()).decode()
        expression = table['partitions'][0]['source']['expression']
        matching = [i for i, line in enumerate(expression) if 'Source = Json.Document(Binary.FromText(' in line]
        if len(matching) != 1:
            raise ValueError(f'{name}: embedded-source expression was changed; review manually.')
        expression[matching[0]] = f'    Source = Json.Document(Binary.FromText("{encoded}", BinaryEncoding.Base64)),'
    if any(r['SnapshotDate'] != '2025-12-31' for r in tables['Receivables']):
        raise ValueError('Receivables cutoff changed. Update report labels and review the model first.')
    if any(not ('2024-01-01' <= r['Date'] <= '2025-12-31') for r in tables['Sales']):
        raise ValueError('Sales dates exceed the two fixed report years; review DAX and labels first.')
    calendar = [r['Date'] for r in tables['Calendar']]
    expected_calendar = [(dt.date(2024, 1, 1) + dt.timedelta(days=i)).isoformat() for i in range(731)]
    if sorted(calendar) != expected_calendar:
        raise ValueError('Calendar must cover all 731 days of 2024 and 2025 exactly once.')
    # Validate everything before atomically replacing the model.
    payload = (json.dumps(model, indent=2) + '\n').encode()
    pending = target.with_suffix('.bim.pending')
    pending.write_bytes(payload)
    os.replace(pending, target)
    print('Embedded six-table snapshot updated. Open Power BI Desktop and refresh.')
    print('Source SHA256:', hashlib.sha256(source.read_bytes()).hexdigest())
    print('Review the static PDF and repeat validation if any input values changed.')


if __name__ == '__main__':
    main()
