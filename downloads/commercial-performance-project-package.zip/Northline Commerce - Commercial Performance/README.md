# Northline Commerce | Commercial Performance & Receivables

Prepared by **Trimanjeev Sawhney**. Independent portfolio project using reproducible fictional data. Calendar years 2024 and 2025; receivables as of **31 December 2025**. All amounts are CAD.

The project connects raw sales and payment records to SQL controls, commercial analysis and a Power BI report definition. It evaluates revenue, gross margin, product and customer contribution, invoice aging and collection priorities.

## Start here

Read **Commercial Performance - Research Report.pdf** for the three-page analytical review. This is the primary presentation document: commercial results, margin drivers, collection priorities and measurement conventions. It is a standalone report, not a Power BI export.

The `SQL Analysis` folder contains the raw CSV data, SQL scripts, reproducible runner, SQLite database, reporting extracts, data dictionary and validation results. Its README explains how to rerun the pipeline and inspect every calculation.

The `Power BI` folder contains `Northline Commerce.pbip`, `Northline Commerce.Report` and `Northline Commerce.SemanticModel`. Preserve the folder structure when extracting or sharing the project.

## Readiness and verification

The SQL calculations and analytical PDF have been checked. Thirteen pipeline controls reconcile invoices, sales lines and receivables, account for every accepted or quarantined record, and test eight aging/payment boundary cases. A separate audit passed 132 checks and seven input-mutation cases. All three PDF pages were visually reviewed.

The Power BI report definitions passed Microsoft Report Authoring CLI 0.1.4 with zero errors and zero warnings. A separate static model review passed 88 checks covering embedded data, relationships, measure references and visual fields. The snapshot updater was also tested in a separate copied folder, including rejection of an invalid cutoff without changing the model.

The Power BI project requires its first refresh and visual/interaction verification in **Power BI Desktop on Windows**. Structural file validation does not establish that the Power BI engine has executed every query, measure or visual. See `Power BI/VALIDATION.md` for the remaining checks. This package should not be represented as a natively tested Power BI deployment until that review is complete.

## Open Power BI

1. Extract the complete project to a local folder on Windows.
2. Open `Power BI/Northline Commerce.pbip` in a Power BI Desktop version that supports the included PBIP/PBIR project formats. If Desktop requests the corresponding preview features, enable them and restart it.
3. Refresh the model. It loads an embedded, fixed data snapshot, so no local data-path setup, database connection or network credentials are needed. Review all report pages, slicers and cross-filter interactions. Confirm that the financial totals agree with the values below.
4. Save the validated project. A PDF exported from Power BI after that review can accompany the analytical report; the supplied PDF should not be relabeled as a Power BI export.

## Reference totals

| Measure | Value |
|---|---:|
| FY2024 revenue | $1,152,622.72 |
| FY2025 revenue | $1,402,310.67 |
| FY2025 gross profit | $589,034.50 |
| FY2025 gross margin | 42.0046% |
| Revenue growth | 21.6626% |
| Gross-margin change | -1.6954 percentage points |
| Open receivables | $167,743.96 |
| Overdue receivables | $68,979.21 |
| More than 90 days past due | $5,836.65 |
| Open invoices | 64 |

Use the full-precision reporting exports for reconciliation. The PDF rounds displayed monetary amounts to whole dollars and most percentages to one decimal place.

## Business interpretation

Revenue grew faster than gross profit. Direct-channel revenue increased 63.1%, while Marketplace gross margin declined 7.16 percentage points. The gross-profit bridge separates volume/product-mix, realized-price and unit-cost effects. The first three collection-priority accounts represent 57.7% of overdue balances.

These results support proposed pricing, cost and collections reviews. No collection recovery, pricing improvement or other operational outcome is claimed. All business names, transactions and customer accounts are fictional. Direct and Marketplace customer records represent aggregate account groupings, not individual shoppers.

## Scope

- Revenue is pre-tax merchandise sales after simulated channel pricing and discounts. Gross profit deducts merchandise cost only; fulfillment, marketplace fees, overhead, financing and tax are excluded.
- Sales cover 2024 and 2025. There are no opening balances before January 2024, returns, credit notes, foreign exchange, write-offs or bad-debt provisions.
- Receivables is a fixed snapshot. Payments dated on or before 31 December 2025 count; later payments remain in the source ledger but are excluded from the balance.
- Current includes invoices due on the snapshot date. Other buckets are 1-30, 31-60, 61-90 and 91+ days past due.
- Invoice balances are calculated after payments are aggregated by invoice, avoiding repetition across sales lines.
- Synthetic source generation uses seed 42175. Nine deliberate invalid/duplicate source records are quarantined; eight small invoices test aging boundaries. The case is a reproducible analytical demonstration, not an actual employer engagement or a live accounting system.

## Sharing and changes

Send the PDF for an initial review and the complete package when calculation detail is requested. Retain the disclosed Power BI verification status when sharing its source files. Do not publish confidential data into this synthetic case.

The SQL runner regenerates the database and reporting extracts from the supplied sources. To update the embedded Power BI data after rerunning SQL, run `update_snapshot.py` from the `Power BI` folder using Python 3, then reopen and refresh the project in Desktop. Keep the sibling `SQL Analysis` folder in place so the updater can find `outputs/model_data.json`.

The analytical PDF is static and must be regenerated after input changes. Rerunning SQL alone does not automatically rewrite the PDF or the embedded Power BI snapshot. Recheck all totals and visual interactions after an update.
