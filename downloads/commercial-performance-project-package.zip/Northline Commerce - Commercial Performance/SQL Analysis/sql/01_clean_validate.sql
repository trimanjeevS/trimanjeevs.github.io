-- SQLite 3.25+. Raw columns remain text: never cast before validating numeric syntax.
-- Input order (SourceRow) is authoritative: the first occurrence of a normalized key wins.
CREATE TABLE Customers AS
SELECT upper(trim(CustomerID)) CustomerID,trim(CustomerName) CustomerName FROM raw_customers;
CREATE UNIQUE INDEX ux_customers ON Customers(CustomerID);
CREATE TABLE Products AS
SELECT upper(trim(ProductID)) ProductID,trim(ProductName) ProductName,trim(Category) Category FROM raw_products;
CREATE UNIQUE INDEX ux_products ON Products(ProductID);

CREATE TABLE InvoiceReview AS
WITH n AS (
 SELECT SourceRow,upper(trim(InvoiceID)) InvoiceID,trim(InvoiceDate) InvoiceDate,trim(DueDate) DueDate,
 upper(trim(CustomerID)) CustomerID,
 CASE lower(trim(Channel)) WHEN 'wholesale' THEN 'Wholesale' WHEN 'marketplace' THEN 'Marketplace' WHEN 'direct' THEN 'Direct' ELSE trim(Channel) END Channel,
 trim(InvoiceAmountCents) InvoiceAmountCents,
 row_number() OVER(PARTITION BY upper(trim(InvoiceID)) ORDER BY SourceRow) rn FROM raw_invoices
)
SELECT *,CASE
 WHEN InvoiceID='' THEN 'MISSING_INVOICE_ID'
 WHEN rn>1 THEN 'DUPLICATE_INVOICE_ID'
 WHEN length(InvoiceDate)<>10 OR date(InvoiceDate,'+0 days') IS NULL OR date(InvoiceDate,'+0 days')<>InvoiceDate OR InvoiceDate<'2024-01-01' OR InvoiceDate>'2025-12-31' THEN 'INVALID_INVOICE_DATE'
 WHEN length(DueDate)<>10 OR date(DueDate,'+0 days') IS NULL OR date(DueDate,'+0 days')<>DueDate OR DueDate<InvoiceDate THEN 'INVALID_DUE_DATE'
 WHEN CustomerID NOT IN (SELECT CustomerID FROM Customers) THEN 'UNKNOWN_CUSTOMER'
 WHEN Channel NOT IN ('Wholesale','Marketplace','Direct') THEN 'INVALID_CHANNEL'
 WHEN InvoiceAmountCents='' OR InvoiceAmountCents GLOB '*[^0-9]*' OR length(InvoiceAmountCents)>12 OR CAST(InvoiceAmountCents AS INTEGER)<=0 THEN 'INVALID_INVOICE_AMOUNT'
 ELSE NULL END RejectionReason FROM n;

CREATE TABLE LineReview AS
WITH n AS (
 SELECT SourceRow,upper(trim(LineID)) LineID,upper(trim(InvoiceID)) InvoiceID,upper(trim(ProductID)) ProductID,
 trim(Units) Units,trim(UnitPriceCents) UnitPriceCents,trim(UnitCostCents) UnitCostCents,
 row_number() OVER(PARTITION BY upper(trim(LineID)) ORDER BY SourceRow) rn FROM raw_sales_lines
)
SELECT *,CASE
 WHEN LineID='' THEN 'MISSING_LINE_ID'
 WHEN rn>1 THEN 'DUPLICATE_LINE_ID'
 WHEN InvoiceID NOT IN (SELECT InvoiceID FROM InvoiceReview WHERE RejectionReason IS NULL) THEN 'UNKNOWN_OR_REJECTED_INVOICE'
 WHEN ProductID NOT IN (SELECT ProductID FROM Products) THEN 'UNKNOWN_PRODUCT'
 WHEN Units='' OR Units GLOB '*[^0-9]*' OR length(Units)>6 OR CAST(Units AS INTEGER)<=0 THEN 'INVALID_UNITS'
 WHEN UnitPriceCents='' OR UnitPriceCents GLOB '*[^0-9]*' OR length(UnitPriceCents)>9 OR CAST(UnitPriceCents AS INTEGER)<=0 THEN 'INVALID_UNIT_PRICE'
 WHEN UnitCostCents='' OR UnitCostCents GLOB '*[^0-9]*' OR length(UnitCostCents)>9 THEN 'INVALID_UNIT_COST'
 ELSE NULL END RejectionReason FROM n;

CREATE TABLE InvoiceTotals AS
SELECT InvoiceID,SUM(CAST(Units AS INTEGER)*CAST(UnitPriceCents AS INTEGER)) LineRevenueCents
FROM LineReview WHERE RejectionReason IS NULL GROUP BY InvoiceID;
UPDATE InvoiceReview SET RejectionReason='INVOICE_LINE_TOTAL_MISMATCH'
WHERE RejectionReason IS NULL AND NOT EXISTS(
 SELECT 1 FROM InvoiceTotals t WHERE t.InvoiceID=InvoiceReview.InvoiceID AND t.LineRevenueCents=CAST(InvoiceReview.InvoiceAmountCents AS INTEGER));
UPDATE LineReview SET RejectionReason='PARENT_INVOICE_REJECTED'
WHERE RejectionReason IS NULL AND InvoiceID NOT IN (SELECT InvoiceID FROM InvoiceReview WHERE RejectionReason IS NULL);

CREATE TABLE Invoices AS
SELECT InvoiceID,InvoiceDate,DueDate,CustomerID,Channel,CAST(InvoiceAmountCents AS INTEGER) InvoiceAmountCents
FROM InvoiceReview WHERE RejectionReason IS NULL;
CREATE UNIQUE INDEX ux_invoices ON Invoices(InvoiceID);
CREATE TABLE SalesLines AS
SELECT LineID,InvoiceID,ProductID,CAST(Units AS INTEGER) Units,CAST(UnitPriceCents AS INTEGER) UnitPriceCents,CAST(UnitCostCents AS INTEGER) UnitCostCents
FROM LineReview WHERE RejectionReason IS NULL;
CREATE UNIQUE INDEX ux_sales_lines ON SalesLines(LineID);

CREATE TABLE PaymentReview AS
WITH n AS (
 SELECT SourceRow,upper(trim(PaymentID)) PaymentID,upper(trim(InvoiceID)) InvoiceID,
 trim(PaymentDate) PaymentDate,trim(AmountCents) AmountCents,
 row_number() OVER(PARTITION BY upper(trim(PaymentID)) ORDER BY SourceRow) rn FROM raw_payments
)
SELECT *,CASE
 WHEN PaymentID='' THEN 'MISSING_PAYMENT_ID'
 WHEN rn>1 THEN 'DUPLICATE_PAYMENT_ID'
 WHEN InvoiceID NOT IN (SELECT InvoiceID FROM Invoices) THEN 'UNKNOWN_OR_REJECTED_INVOICE'
 WHEN length(PaymentDate)<>10 OR date(PaymentDate,'+0 days') IS NULL OR date(PaymentDate,'+0 days')<>PaymentDate OR PaymentDate<(SELECT InvoiceDate FROM Invoices i WHERE i.InvoiceID=n.InvoiceID) THEN 'INVALID_PAYMENT_DATE'
 WHEN AmountCents='' OR AmountCents GLOB '*[^0-9]*' OR length(AmountCents)>12 OR CAST(AmountCents AS INTEGER)<=0 THEN 'INVALID_PAYMENT_AMOUNT'
 ELSE NULL END RejectionReason FROM n;
CREATE TABLE Payments AS
SELECT PaymentID,InvoiceID,PaymentDate,CAST(AmountCents AS INTEGER) AmountCents FROM PaymentReview WHERE RejectionReason IS NULL;
CREATE UNIQUE INDEX ux_payments ON Payments(PaymentID);

CREATE VIEW Quarantine AS
SELECT 'Invoices' SourceTable,SourceRow,InvoiceID RecordID,RejectionReason FROM InvoiceReview WHERE RejectionReason IS NOT NULL
UNION ALL SELECT 'SalesLines',SourceRow,LineID,RejectionReason FROM LineReview WHERE RejectionReason IS NOT NULL
UNION ALL SELECT 'Payments',SourceRow,PaymentID,RejectionReason FROM PaymentReview WHERE RejectionReason IS NOT NULL;
