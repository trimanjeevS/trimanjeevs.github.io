-- Analytical layer retains integer cents. A single snapshot controls all receivables.
CREATE TABLE ReportParameters(SnapshotDate TEXT NOT NULL,ReportYear INTEGER NOT NULL,PriorYear INTEGER NOT NULL);
INSERT INTO ReportParameters VALUES('2025-12-31',2025,2024);

CREATE VIEW Sales AS
SELECT l.LineID,l.InvoiceID,i.InvoiceDate Date,i.CustomerID,l.ProductID,i.Channel,l.Units,
 l.Units*l.UnitPriceCents RevenueCents,l.Units*l.UnitCostCents COGSCents,
 l.Units*(l.UnitPriceCents-l.UnitCostCents) GrossProfitCents
FROM SalesLines l JOIN Invoices i ON i.InvoiceID=l.InvoiceID;

-- Aggregate payments BEFORE joining invoices; never join payments directly to sales lines.
CREATE VIEW InvoiceBalances AS
WITH p AS (
 SELECT InvoiceID,SUM(AmountCents) PaidToDateCents FROM Payments
 WHERE PaymentDate<=(SELECT SnapshotDate FROM ReportParameters) GROUP BY InvoiceID
), b AS (
 SELECT r.SnapshotDate,i.*,COALESCE(p.PaidToDateCents,0) PaidToDateCents,
 i.InvoiceAmountCents-COALESCE(p.PaidToDateCents,0) OutstandingCents,
 CAST(MAX(julianday(r.SnapshotDate)-julianday(i.DueDate),0) AS INTEGER) DaysPastDue
 FROM Invoices i CROSS JOIN ReportParameters r LEFT JOIN p ON p.InvoiceID=i.InvoiceID
 WHERE i.InvoiceDate<=r.SnapshotDate
)
SELECT *,CASE WHEN DaysPastDue=0 THEN 'Current' WHEN DaysPastDue<=30 THEN '1-30 days'
 WHEN DaysPastDue<=60 THEN '31-60 days' WHEN DaysPastDue<=90 THEN '61-90 days' ELSE '91+ days' END AgingBucket,
 CASE WHEN DaysPastDue=0 THEN 0 WHEN DaysPastDue<=30 THEN 1 WHEN DaysPastDue<=60 THEN 2 WHEN DaysPastDue<=90 THEN 3 ELSE 4 END AgingSort
FROM b;
CREATE VIEW Receivables AS SELECT * FROM InvoiceBalances WHERE OutstandingCents>0;

CREATE VIEW MonthlyPerformance AS
SELECT substr(Date,1,7) YearMonth,CAST(substr(Date,1,4) AS INTEGER) Year,CAST(substr(Date,6,2) AS INTEGER) MonthNumber,
 COUNT(DISTINCT InvoiceID) InvoiceCount,SUM(Units) Units,SUM(RevenueCents) RevenueCents,SUM(COGSCents) COGSCents,SUM(GrossProfitCents) GrossProfitCents
FROM Sales GROUP BY substr(Date,1,7);
CREATE VIEW ChannelPerformance AS
SELECT CAST(substr(Date,1,4) AS INTEGER) Year,Channel,COUNT(DISTINCT InvoiceID) InvoiceCount,
 SUM(Units) Units,SUM(RevenueCents) RevenueCents,SUM(COGSCents) COGSCents,SUM(GrossProfitCents) GrossProfitCents
FROM Sales GROUP BY CAST(substr(Date,1,4) AS INTEGER),Channel;
CREATE VIEW ProductPerformance AS
SELECT CAST(substr(s.Date,1,4) AS INTEGER) Year,p.ProductID,p.ProductName,p.Category,SUM(s.Units) Units,
 SUM(s.RevenueCents) RevenueCents,SUM(s.COGSCents) COGSCents,SUM(s.GrossProfitCents) GrossProfitCents
FROM Sales s JOIN Products p ON p.ProductID=s.ProductID GROUP BY CAST(substr(s.Date,1,4) AS INTEGER),p.ProductID;
CREATE VIEW CustomerPerformance AS
SELECT CAST(substr(s.Date,1,4) AS INTEGER) Year,c.CustomerID,c.CustomerName,COUNT(DISTINCT s.InvoiceID) InvoiceCount,
 SUM(s.RevenueCents) RevenueCents,SUM(s.COGSCents) COGSCents,SUM(s.GrossProfitCents) GrossProfitCents
FROM Sales s JOIN Customers c ON c.CustomerID=s.CustomerID GROUP BY CAST(substr(s.Date,1,4) AS INTEGER),c.CustomerID;
CREATE VIEW AgingSummary AS
SELECT AgingSort,AgingBucket,COUNT(*) InvoiceCount,SUM(OutstandingCents) OutstandingCents FROM Receivables GROUP BY AgingSort,AgingBucket;
CREATE VIEW CustomerReceivables AS
SELECT c.CustomerID,c.CustomerName,COUNT(*) OpenInvoiceCount,SUM(r.OutstandingCents) OutstandingCents,
 SUM(CASE WHEN r.DaysPastDue>0 THEN r.OutstandingCents ELSE 0 END) OverdueCents,
 SUM(CASE WHEN r.DaysPastDue>90 THEN r.OutstandingCents ELSE 0 END) Over90Cents,
 MAX(r.DaysPastDue) OldestDaysPastDue
FROM Receivables r JOIN Customers c ON c.CustomerID=r.CustomerID GROUP BY c.CustomerID;

-- Isolate price, unit-cost and volume/mix movements by channel/product before aggregation.
-- Average prices/costs are ratio-based; bridge components use REAL arithmetic only for analysis.
CREATE VIEW MarginBridge AS
WITH a AS(
 SELECT substr(Date,1,4) Year,Channel,ProductID,SUM(Units) Units,SUM(RevenueCents) RevenueCents,SUM(COGSCents) COGSCents
 FROM Sales GROUP BY substr(Date,1,4),Channel,ProductID
), b AS(
 SELECT c.Channel,c.ProductID,p.Units PriorUnits,c.Units CurrentUnits,
 p.RevenueCents*1.0/p.Units PriorPrice,p.COGSCents*1.0/p.Units PriorUnitCost,
 c.RevenueCents*1.0/c.Units CurrentPrice,c.COGSCents*1.0/c.Units CurrentUnitCost
 FROM a c JOIN a p ON c.Channel=p.Channel AND c.ProductID=p.ProductID WHERE c.Year='2025' AND p.Year='2024'
)
SELECT Channel,ProductID,(CurrentUnits-PriorUnits)*(PriorPrice-PriorUnitCost) VolumeMixImpactCents,
 CurrentUnits*(CurrentPrice-PriorPrice) PriceImpactCents,
 -CurrentUnits*(CurrentUnitCost-PriorUnitCost) UnitCostImpactCents FROM b;
