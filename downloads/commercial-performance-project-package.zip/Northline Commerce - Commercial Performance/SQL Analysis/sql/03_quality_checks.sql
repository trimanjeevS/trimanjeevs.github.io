-- Every row is a failing-record count or exact-cent difference. All results must be zero.
SELECT 'invoice_line_reconciliation_cents' CheckName,
 (SELECT SUM(InvoiceAmountCents) FROM Invoices)-(SELECT SUM(RevenueCents) FROM Sales) Actual
UNION ALL SELECT 'negative_open_balances',COUNT(*) FROM InvoiceBalances WHERE OutstandingCents<0
UNION ALL SELECT 'overpaid_full_ledger_invoices',COUNT(*) FROM
 (SELECT i.InvoiceID FROM Invoices i JOIN Payments p ON p.InvoiceID=i.InvoiceID GROUP BY i.InvoiceID HAVING SUM(p.AmountCents)>MAX(i.InvoiceAmountCents))
UNION ALL SELECT 'revenue_less_cogs_less_gp_cents',SUM(RevenueCents-COGSCents-GrossProfitCents) FROM Sales
UNION ALL SELECT 'snapshot_balance_reconciliation_cents',SUM(InvoiceAmountCents-PaidToDateCents-OutstandingCents) FROM InvoiceBalances
UNION ALL SELECT 'sales_orphan_customers',COUNT(*) FROM Sales s LEFT JOIN Customers c ON c.CustomerID=s.CustomerID WHERE c.CustomerID IS NULL
UNION ALL SELECT 'sales_orphan_products',COUNT(*) FROM Sales s LEFT JOIN Products p ON p.ProductID=s.ProductID WHERE p.ProductID IS NULL
UNION ALL SELECT 'unexpected_month_count',ABS(COUNT(*)-24) FROM MonthlyPerformance
UNION ALL SELECT 'unexpected_quarantine_count',ABS(COUNT(*)-9) FROM Quarantine
UNION ALL SELECT 'invoice_row_coverage',
 (SELECT COUNT(*) FROM raw_invoices)-(SELECT COUNT(*) FROM Invoices)-(SELECT COUNT(*) FROM InvoiceReview WHERE RejectionReason IS NOT NULL)
UNION ALL SELECT 'line_row_coverage',
 (SELECT COUNT(*) FROM raw_sales_lines)-(SELECT COUNT(*) FROM SalesLines)-(SELECT COUNT(*) FROM LineReview WHERE RejectionReason IS NOT NULL)
UNION ALL SELECT 'payment_row_coverage',
 (SELECT COUNT(*) FROM raw_payments)-(SELECT COUNT(*) FROM Payments)-(SELECT COUNT(*) FROM PaymentReview WHERE RejectionReason IS NOT NULL);
