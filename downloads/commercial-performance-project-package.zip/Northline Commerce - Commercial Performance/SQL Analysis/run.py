"""Rebuild the database and published extracts from preserved raw CSV files.

Usage: python3 run.py
Optional: python3 generate_data.py  # restore the original fixed-seed source fixture
No third-party packages or network access required.
"""
from pathlib import Path
import csv, json, sqlite3
from datetime import date, timedelta

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs'

def main():
    OUT.mkdir(exist_ok=True)
    db=OUT/'northline_commerce.sqlite'
    if db.exists(): db.unlink()
    con=sqlite3.connect(db)
    con.row_factory=sqlite3.Row
    for filename in ('raw_customers','raw_products','raw_invoices','raw_sales_lines','raw_payments'):
        with (ROOT/'data'/f'{filename}.csv').open(newline='',encoding='utf-8') as f:
            reader=csv.DictReader(f); headers=reader.fieldnames
            con.execute(f'CREATE TABLE "{filename}"(SourceRow INTEGER PRIMARY KEY,'+','.join(f'"{h}" TEXT NOT NULL' for h in headers)+')')
            con.executemany(f'INSERT INTO "{filename}" VALUES('+','.join('?' for _ in range(len(headers)+1))+')',
                [(n,*[row[h] for h in headers]) for n,row in enumerate(reader,2)])
    for name in ('01_clean_validate.sql','02_reporting_views.sql'):
        con.executescript((ROOT/'sql'/name).read_text())
    checks=[dict(r) for r in con.execute((ROOT/'sql'/'03_quality_checks.sql').read_text())]
    def rows(query): return [dict(r) for r in con.execute(query)]
    def csvout(name,records):
        if not records: return
        with (OUT/f'{name}.csv').open('w',newline='',encoding='utf-8') as f:
            w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
    fixtures=list(csv.DictReader((ROOT/'data'/'aging_boundary_fixtures.csv').open()))
    boundary=[]
    for f in fixtures:
        b=dict(con.execute('SELECT * FROM Receivables WHERE InvoiceID=?',(f['InvoiceID'],)).fetchone())
        result=(b['DaysPastDue']==int(f['ExpectedDaysPastDue']) and b['PaidToDateCents']==11000 and b['OutstandingCents']==33000)
        boundary.append({'InvoiceID':f['InvoiceID'],'DaysPastDue':b['DaysPastDue'],'AgingBucket':b['AgingBucket'],'PaidToDateCents':b['PaidToDateCents'],'OutstandingCents':b['OutstandingCents'],'Passed':result})
    checks.append({'CheckName':'aging_and_payment_boundary_fixtures','Actual':sum(not b['Passed'] for b in boundary)})
    failed=[r for r in checks if r['Actual']!=0]
    if failed: raise ValueError(f'Quality checks failed: {failed}')
    for name,query in {
        'accepted_customers':'SELECT * FROM Customers ORDER BY CustomerID',
        'accepted_products':'SELECT * FROM Products ORDER BY ProductID',
        'accepted_invoices':'SELECT * FROM Invoices ORDER BY InvoiceID',
        'accepted_sales_lines':'SELECT * FROM SalesLines ORDER BY LineID',
        'accepted_payments':'SELECT * FROM Payments ORDER BY PaymentID',
        'quarantine':'SELECT * FROM Quarantine ORDER BY SourceTable,SourceRow',
        'reporting_sales_cents':'SELECT * FROM Sales ORDER BY LineID',
        'reporting_invoice_balances_cents':'SELECT * FROM InvoiceBalances ORDER BY InvoiceID',
        'reporting_receivables_cents':'SELECT * FROM Receivables ORDER BY InvoiceID',
        'reporting_monthly_cents':'SELECT * FROM MonthlyPerformance ORDER BY YearMonth',
        'reporting_channels_cents':'SELECT * FROM ChannelPerformance ORDER BY Year,Channel',
        'reporting_products_cents':'SELECT * FROM ProductPerformance ORDER BY Year,ProductID',
        'reporting_customers_cents':'SELECT * FROM CustomerPerformance ORDER BY Year,CustomerID',
        'reporting_aging_cents':'SELECT * FROM AgingSummary ORDER BY AgingSort',
        'reporting_customer_receivables_cents':'SELECT * FROM CustomerReceivables ORDER BY OverdueCents DESC,OldestDaysPastDue DESC,CustomerID',
        'reporting_margin_bridge_cents':'SELECT * FROM MarginBridge ORDER BY Channel,ProductID'
    }.items(): csvout(name,rows(query))
    csvout('quality_checks',checks);csvout('boundary_checks',boundary)
    sales=rows('SELECT LineID,InvoiceID,Date,CustomerID,ProductID,Channel,Units,RevenueCents/100.0 Revenue,COGSCents/100.0 COGS,GrossProfitCents/100.0 GrossProfit FROM Sales ORDER BY LineID')
    ar=rows('SELECT SnapshotDate,InvoiceID,InvoiceDate,DueDate,CustomerID,Channel,InvoiceAmountCents/100.0 InvoiceAmount,PaidToDateCents/100.0 PaidToDate,OutstandingCents/100.0 Outstanding,DaysPastDue,AgingBucket,AgingSort FROM Receivables ORDER BY InvoiceID')
    dates=[]; d=date(2024,1,1)
    while d<=date(2025,12,31):
        dates.append({'Date':d.isoformat(),'Year':d.year,'Month':d.strftime('%b'),'MonthNumber':d.month,'YearMonth':d.strftime('%Y-%m')})
        d+=timedelta(days=1)
    metadata={
        'project':'Northline Commerce | Commercial Performance & Receivables',
        'data_type':'Fictional, reproducible portfolio case; no real customer or employer data',
        'currency':'CAD','money_basis':'Pre-tax merchandise revenue; exported dollars, database integer cents',
        'report_year':2025,'prior_year':2024,'snapshot_date':'2025-12-31','source_start':'2024-01-01','source_end':'2025-12-31',
        'calendar_rows':len(dates),'source_seed':42175,
        'receivables_scope':'Open invoices only at fixed snapshot. Payments on snapshot included; later payments excluded. No opening pre-2024 balances.',
        'gross_profit_scope':'Revenue less merchandise COGS; excludes fulfillment, marketplace fees, overhead, tax and financing.',
        'limitations':['Fictional data; no evidence of actual business results.','No credit notes, returns, taxes, FX, write-offs, bad-debt provision or pre-2024 opening balances.','Direct and Marketplace customers represent fictional aggregate account groupings, not individual shoppers.','Receivables is a fixed snapshot, not a historical aging time series.','Annual average realized prices and costs include transaction-level discount mix.']}
    data={'metadata':metadata,'tables':{'Sales':sales,'Customers':rows('SELECT * FROM Customers ORDER BY CustomerID'),'Products':rows('SELECT * FROM Products ORDER BY ProductID'),'Calendar':dates,'Channels':[{'Channel':c} for c in ['Wholesale','Marketplace','Direct']],'Receivables':ar}}
    def money(r):
        result={k[:-5] if k.endswith('Cents') else k:v/100 if k.endswith('Cents') else v for k,v in r.items()}
        if 'Revenue' in result: result['GrossMargin']=result['GrossProfit']/result['Revenue'] if result['Revenue'] else None
        return result
    annual=[money(r) for r in rows('SELECT Year,SUM(InvoiceCount) InvoiceCount,SUM(Units) Units,SUM(RevenueCents) RevenueCents,SUM(COGSCents) COGSCents,SUM(GrossProfitCents) GrossProfitCents FROM MonthlyPerformance GROUP BY Year ORDER BY Year')]
    a24,a25=annual
    kpis={**a25,'PriorRevenue':a24['Revenue'],'PriorGrossProfit':a24['GrossProfit'],'PriorGrossMargin':a24['GrossMargin'],
        'RevenueGrowth':a25['Revenue']/a24['Revenue']-1,'GrossProfitGrowth':a25['GrossProfit']/a24['GrossProfit']-1,
        'GrossMarginChangePP':(a25['GrossMargin']-a24['GrossMargin'])*100}
    ar_summary=money(rows('SELECT COUNT(*) OpenInvoiceCount,SUM(OutstandingCents) OutstandingCents,SUM(CASE WHEN DaysPastDue>0 THEN OutstandingCents ELSE 0 END) OverdueCents,SUM(CASE WHEN DaysPastDue>90 THEN OutstandingCents ELSE 0 END) Over90Cents,MAX(DaysPastDue) OldestDaysPastDue FROM Receivables')[0])
    ar_summary['OverdueShare']=ar_summary['Overdue']/ar_summary['Outstanding']
    ar_summary['Over90Share']=ar_summary['Over90']/ar_summary['Outstanding']
    counts={t:{'Raw':con.execute(f'SELECT COUNT(*) FROM raw_{raw}').fetchone()[0],'Accepted':con.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0],'Rejected':con.execute('SELECT COUNT(*) FROM Quarantine WHERE SourceTable=?',(t,)).fetchone()[0]} for t,raw in [('Invoices','invoices'),('SalesLines','sales_lines'),('Payments','payments')]}
    channel=[money(r) for r in rows('SELECT * FROM ChannelPerformance ORDER BY Year,Channel')]
    channel_byyear={(r['Year'],r['Channel']):r for r in channel}
    for r in channel:
        r['RevenueContribution']=r['Revenue']/next(a['Revenue'] for a in annual if a['Year']==r['Year'])
        if r['Year']==2025:
            prev=channel_byyear[(2024,r['Channel'])]
            r['RevenueGrowth']=r['Revenue']/prev['Revenue']-1
            r['GrossMarginChangePP']=(r['GrossMargin']-prev['GrossMargin'])*100
    top_customers=[money(r) for r in rows('SELECT * FROM CustomerReceivables ORDER BY OverdueCents DESC,OldestDaysPastDue DESC,CustomerID')]
    for r in top_customers: r['OverdueContribution']=r['Overdue']/ar_summary['Overdue'] if ar_summary['Overdue'] else 0
    bridge=[money(r) for r in rows('SELECT Channel,SUM(VolumeMixImpactCents) VolumeMixImpactCents,SUM(PriceImpactCents) PriceImpactCents,SUM(UnitCostImpactCents) UnitCostImpactCents FROM MarginBridge GROUP BY Channel ORDER BY Channel')]
    bridge_total={k:sum(r[k] for r in bridge) for k in ['VolumeMixImpact','PriceImpact','UnitCostImpact']}
    bridge_total['GrossProfitChange']=a25['GrossProfit']-a24['GrossProfit']
    bridge_total['Residual']=sum(bridge_total[k] for k in ['VolumeMixImpact','PriceImpact','UnitCostImpact'])-bridge_total['GrossProfitChange']
    if abs(bridge_total['Residual'])>0.00001: raise ValueError('Margin bridge failed')
    metrics={
        'metadata':metadata,'annual':annual,'kpis':kpis,
        'monthly':[money(r) for r in rows('SELECT * FROM MonthlyPerformance ORDER BY YearMonth')],
        'channels':channel,'products':[money(r) for r in rows('SELECT * FROM ProductPerformance ORDER BY Year,RevenueCents DESC')],
        'customers':[money(r) for r in rows('SELECT * FROM CustomerPerformance ORDER BY Year,RevenueCents DESC')],
        'receivables':ar_summary,'aging':[money(r) for r in rows('SELECT * FROM AgingSummary ORDER BY AgingSort')],
        'receivables_by_channel':[money(r) for r in rows('SELECT Channel,COUNT(*) OpenInvoiceCount,SUM(OutstandingCents) OutstandingCents,SUM(CASE WHEN DaysPastDue>0 THEN OutstandingCents ELSE 0 END) OverdueCents FROM Receivables GROUP BY Channel')],
        'collection_priorities':top_customers,
        'top_overdue_invoices':[{**r,'CustomerName':next(c['CustomerName'] for c in data['tables']['Customers'] if c['CustomerID']==r['CustomerID'])} for r in sorted(ar,key=lambda r:(-r['DaysPastDue'],-r['Outstanding'],r['InvoiceID']))[:12]],
        'margin_bridge':{'channels':bridge,'total':bridge_total,'method':'At channel/product grain: (Q25-Q24)*(P24-C24); Q25*(P25-P24); -Q25*(C25-C24). Annual weighted-average realized prices and unit costs. Volume/mix captures quantity changes by product; not a pure demand causal attribution.'},
        'data_quality':{'counts':counts,'rejected_total':sum(r['Rejected'] for r in counts.values()),'checks':checks,'boundary_fixtures':boundary,'quarantine':rows('SELECT * FROM Quarantine ORDER BY SourceTable,SourceRow'),
            'payments_after_snapshot':money(rows("SELECT COUNT(*) PaymentCount,COALESCE(SUM(AmountCents),0) AmountCents FROM Payments WHERE PaymentDate>'2025-12-31'")[0]),
            'payments_on_snapshot':money(rows("SELECT COUNT(*) PaymentCount,COALESCE(SUM(AmountCents),0) AmountCents FROM Payments WHERE PaymentDate='2025-12-31'")[0])}}
    (OUT/'model_data.json').write_text(json.dumps(data,indent=2)+'\n')
    (OUT/'metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
    con.commit();con.close()
    print(json.dumps({'database':str(db),'accepted':counts,'annual':annual,'receivables':ar_summary,'checks_passed':len(checks)},indent=2))

if __name__=='__main__': main()
