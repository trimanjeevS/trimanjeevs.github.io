# Northline Commerce — SQL analysis

An independent portfolio case using reproducible fictional wholesale and ecommerce data. Prepared by Trimanjeev Sawhney. All monetary amounts are CAD; business names and transactions are fictional.

## Reproduce

With Python 3.10 or newer, open a terminal in this folder and run:

```text
python3 run.py
```

No packages, database server or network connection are required. The command replaces only this package's generated `outputs/` database and extracts. Source CSV files are preserved. Optional `python3 generate_data.py` restores the original fixed-seed source CSV fixture. Running the two commands recreates the original results.

## Read the analysis

- `sql/01_clean_validate.sql`: text normalization, strict numeric/date checks, duplicate handling, reference checks and quarantine.
- `sql/02_reporting_views.sql`: monthly, channel, customer and product summaries; invoice-level receivables; aging and gross-profit bridge.
- `sql/03_quality_checks.sql`: exact-cent reconciliation and accepted/rejected coverage controls.
- `outputs/northline_commerce.sqlite`: self-contained database containing raw records, review decisions, accepted records and analytical views.
- `outputs/model_data.json`: exact common data source for the accompanying dashboard. Monetary values are converted from integer cents to CAD dollars at export only.
- `outputs/metrics.json`: reproducible report metrics; generated directly from SQL views.
- `outputs/accepted_*.csv`: accepted source records, with monetary amounts in cents.
- `outputs/reporting_*_cents.csv`: detailed and summarized analytical tables, monetary amounts in cents.
- `outputs/quarantine.csv`: all rejected source records with original CSV row number and reason.
- `outputs/quality_checks.csv` and `outputs/boundary_checks.csv`: validation results.
- `verification/`: independent standard-library audit, its results and portable execution instructions. Run `python3 verification/audit_pipeline.py` after rebuilding; it verifies the data and SQL, not native Power BI or DAX execution.

## Reporting definitions

Revenue is merchandise revenue on invoices dated within the reporting year, after simulated channel pricing and discounts, before tax. COGS is invoiced units multiplied by their recorded merchandise unit costs. Gross profit is revenue less this COGS; it excludes fulfillment, marketplace fees, overhead, financing and tax and must not be described as net profit. Annual channel and product contributions use total same-year revenue as denominator.

Sales covers 1 January 2024 to 31 December 2025. There are no opening receivables from before 2024. There are no credit notes, returns, taxes, currency conversions, write-offs or bad-debt provisions. Wholesale invoices have 30-day terms; Direct and Marketplace invoices have seven-day terms and typically settle within one to five days. Non-wholesale customer names are fictional aggregate account groupings, not individual shoppers.

Receivables is fixed at 31 December 2025. Payments dated on or before that date are included; later payments are retained in the ledger but excluded from this snapshot. Payment totals are aggregated by invoice before any invoice join, avoiding multiplication by the number of sales lines. Open balances equal invoice amount less accepted payments at the cutoff. Only positive balances appear in the dashboard Receivables table. Days past due is the greater of zero and snapshot date minus due date. Current includes invoices due on the snapshot date and future due dates. Aging buckets are 0, 1–30, 31–60, 61–90 and 91 or more days. The last bucket is labeled “91+ days”. Sales period selections do not turn this fixed receivables snapshot into historical aging.

Customer collection priorities are ranked by overdue balance, then oldest days past due and customer ID. High balances identify accounts for follow-up; the data does not establish impairment or a bad-debt provision. Recommendations are proposed actions, not claimed achievements.

The gross-profit bridge is calculated for every channel/product pair. Using year-specific units Q, weighted-average realized price P and unit cost C, the components are `(Q25-Q24)*(P24-C24)` for volume/mix, `Q25*(P25-P24)` for realized price and `-Q25*(C25-C24)` for unit cost. They reconcile to the total gross-profit movement. Average-price movement also reflects transaction discount mix and is not a causal estimate of a pricing intervention. The bridge uses floating-point arithmetic and is checked within a fraction of one cent; financial source reconciliations use exact integer cents.

## Cleaning and controls

Raw CSV columns load as text. Identifiers are trimmed and uppercased; channel labels are trimmed and standardized. Numeric strings must contain only digits, within safe length limits. Positive units, invoice amounts, unit prices and payments are required; valid zero unit costs are accepted. Blank and nonnumeric values never become zero. Canonical ISO dates must survive calendar normalization. Invoice totals must equal accepted line-level sales before an invoice is accepted. Parent rejection propagates to related lines and payments.

Duplicate precedence is stable source order: the first occurrence of each normalized identifier is authoritative, even if it later fails a quality check. Later occurrences are quarantined; the pipeline does not silently replace earlier data. The source CSV row number is recorded, including the header offset. Nine deliberate anomalies exercise invoice, line and payment duplicate checks, invalid date, invalid units, missing amounts and unknown references. All raw records remain available for inspection.

Eight explicit invoice fixtures test 0, 1, 30, 31, 60, 61, 90 and 91 days past due. Each has a CAD 440.00 original balance, a CAD 110.00 payment on 31 December and a further CAD 110.00 payment on 2 January; the snapshot must report CAD 330.00 outstanding. Additional controls reject any final negative invoice balance, reconcile source invoice totals to lines, prove source accepted/rejected coverage and reconcile the monthly reporting coverage.

## Limitations

This is a synthetic portfolio project, not actual business performance or employer work. The payment model deliberately creates interpretable collection-risk patterns. Transaction prices and costs are generated assumptions. The SQL engine is SQLite, with syntax using common SQL patterns plus SQLite date functions and `GLOB` validation. Porting to SQL Server or another engine requires translating those functions. The model is a two-year commercial reporting case with one receivables snapshot; it is not a general accounting ledger or live collections system.
