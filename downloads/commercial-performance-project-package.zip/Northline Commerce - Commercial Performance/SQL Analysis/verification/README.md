# Independent verification

Run from the `SQL Analysis` folder with Python 3.10 or newer:

```text
python3 run.py
python3 verification/audit_pipeline.py
```

The audit also works when invoked from another working directory: it locates the package relative to its own file. To inspect a different copy explicitly, use:

```text
python3 verification/audit_pipeline.py "/path/to/SQL Analysis" --output "/path/to/audit_results.json"
```

No external packages, database service or network access are needed. Successful execution prints `Independent audit: 132 checks passed` and writes `independent_audit.json` beside the audit script unless `--output` is supplied. Any failed check raises an error, exits with a nonzero status and records the failure in that JSON report. Running the audit does not change source data or the published database; mutation cases run against separate in-memory databases.

## What is checked

The auditor independently reconstructs accepted invoices, lines and payments from the raw CSV records without importing the preparation pipeline or reusing its SQL for the expected answers. It compares every accepted record, invoice balance and exported financial row; monthly, annual, product, channel and customer totals; gross-profit bridges; calendar coverage; aging and payment cutoff boundaries; rejection records; and the report's core metrics.

Seven SQL mutation cases check blank, mixed-alphanumeric, decimal and negative payment values; invalid-first duplicate precedence; legitimate zero unit costs; and rejection propagation from an invalid invoice to its lines and payments. The eight aging boundary fixtures independently establish that 0, 1, 30, 31, 60, 61, 90 and 91 days enter the intended buckets. Payments on 31 December are included and payments after that date are excluded from the snapshot.

## Scope and limits

These checks verify the source preparation, SQL calculations, reporting extracts and their financial consistency. The tests named “Power BI import” inspect the JSON records intended for that model. They do **not** execute DAX, refresh Power BI Desktop, render native Power BI visuals or certify runtime interaction behavior. The included audit results explicitly record `native_power_bi_tested: false`.

The portable package was also copied to a separate temporary directory, rebuilt there from its preserved raw CSVs and audited successfully. Generated model data and metrics matched the delivered package byte for byte.
