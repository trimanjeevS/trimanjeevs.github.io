#!/usr/bin/env python3
"""Independent raw-record and report reconciliation for the commercial case study.

Uses only Python's standard library. Does not import the preparation pipeline or
reuse its SQL. Run with the SQL Analysis directory as the optional first argument.
"""
import argparse
import csv
import json
import re
import sqlite3
import copy
from collections import Counter, defaultdict
from datetime import date, timedelta
from pathlib import Path

AS_OF = date(2025, 12, 31)
CHECKS = []


def check(name, condition, detail=None):
    item = {"check": name, "passed": bool(condition)}
    if detail is not None:
        item["detail"] = detail
    CHECKS.append(item)
    if not condition:
        raise AssertionError(f"{name}: {detail}")


def uint(value, positive=False):
    text = str(value).strip()
    if not re.fullmatch(r"[0-9]+", text):
        return None
    result = int(text)
    return None if positive and result == 0 else result


def iso_date(value):
    value = str(value).strip()
    if not re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", value):
        return None
    try:
        parsed = date.fromisoformat(value)
        return parsed if parsed.isoformat() == value else None
    except ValueError:
        return None


def key(value):
    return str(value).strip().upper()


def aging(days):
    if days <= 0:
        return "Current"
    if days <= 30:
        return "1-30 days"
    if days <= 60:
        return "31-60 days"
    if days <= 90:
        return "61-90 days"
    return "91+ days"


def rows(path):
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def sum_by(records, fields, measures):
    result = {}
    for row in records:
        group = tuple(row[field] for field in fields)
        if group not in result:
            result[group] = dict.fromkeys(measures, 0)
        for field in measures:
            result[group][field] += row[field]
    return result


def helper_tests():
    check("Strict integer parser rejects blanks, decimals and malformed values",
          all(uint(v) is None for v in ["", " ", "1.5", "-1", "NaN", "1e3", "1,000", "12x"]))
    check("Legitimate zero remains zero", uint("0") == 0 and uint("0", True) is None)
    check("Date parser requires a real canonical ISO date",
          all(iso_date(v) is None for v in ["2025-02-29", "2025-1-01", "", "2025-13-01"]))
    check("All eight aging boundaries",
          [aging(n) for n in [0, 1, 30, 31, 60, 61, 90, 91]] ==
          ["Current", "1-30 days", "1-30 days", "31-60 days", "31-60 days", "61-90 days", "61-90 days", "91+ days"])


def reconstruct(package):
    """Read original CSVs and build expected results without any SQL execution."""
    raw = {name: rows(package / "data" / f"raw_{name}.csv")
           for name in ["customers", "products", "invoices", "sales_lines", "payments"]}
    customers = {key(r["CustomerID"]): r for r in raw["customers"]}
    products = {key(r["ProductID"]): r for r in raw["products"]}
    check("Customer and product dimensions have unique keys",
          len(customers) == len(raw["customers"]) and len(products) == len(raw["products"]))
    invoices, sales, payments = {}, {}, {}
    rejected = defaultdict(list)
    seen = set()
    for n, r in enumerate(raw["invoices"], 2):
        rid = key(r["InvoiceID"])
        issue, due = iso_date(r["InvoiceDate"]), iso_date(r["DueDate"])
        amount = uint(r["InvoiceAmountCents"], True)
        customer, channel = key(r["CustomerID"]), r["Channel"].strip().title()
        valid = rid and rid not in seen and issue and date(2024,1,1) <= issue <= AS_OF and due and due >= issue and amount is not None and len(r["InvoiceAmountCents"].strip()) <= 12 and customer in customers and channel in ["Wholesale", "Marketplace", "Direct"]
        seen.add(rid)
        if not valid:
            rejected["invoices"].append(n)
            continue
        invoices[rid] = {"InvoiceID": rid, "InvoiceDate": issue.isoformat(), "DueDate": due.isoformat(),
                         "CustomerID": customer, "Channel": channel, "InvoiceAmountCents": amount}
    seen = set()
    for n, r in enumerate(raw["sales_lines"], 2):
        rid, iid, pid = key(r["LineID"]), key(r["InvoiceID"]), key(r["ProductID"])
        units, price, cost = uint(r["Units"], True), uint(r["UnitPriceCents"], True), uint(r["UnitCostCents"])
        valid = rid and rid not in seen and iid in invoices and pid in products and all(v is not None for v in [units, price, cost]) and len(r["Units"].strip()) <= 6 and len(r["UnitPriceCents"].strip()) <= 9 and len(r["UnitCostCents"].strip()) <= 9
        seen.add(rid)
        if not valid:
            rejected["sales_lines"].append(n)
            continue
        inv = invoices[iid]
        sales[rid] = {"LineID": rid, "InvoiceID": iid, "ProductID": pid,
                      "Units": units, "UnitPriceCents": price, "UnitCostCents": cost,
                      "RevenueCents": units * price, "COGSCents": units * cost,
                      "GrossProfitCents": units * (price - cost), "InvoiceDate": inv["InvoiceDate"],
                      "CustomerID": inv["CustomerID"], "Channel": inv["Channel"]}
    invoice_revenues = defaultdict(int)
    for r in sales.values():
        invoice_revenues[r["InvoiceID"]] += r["RevenueCents"]
    mismatched = {iid for iid, r in invoices.items() if invoice_revenues[iid] != r["InvoiceAmountCents"]}
    invoices = {iid:r for iid,r in invoices.items() if iid not in mismatched}
    sales = {lid:r for lid,r in sales.items() if r["InvoiceID"] not in mismatched}
    seen = set()
    for n, r in enumerate(raw["payments"], 2):
        rid, iid = key(r["PaymentID"]), key(r["InvoiceID"])
        when, amount = iso_date(r["PaymentDate"]), uint(r["AmountCents"], True)
        valid = rid and rid not in seen and iid in invoices and when and when >= iso_date(invoices[iid]["InvoiceDate"]) and amount is not None and len(r["AmountCents"].strip()) <= 12
        seen.add(rid)
        if not valid:
            rejected["payments"].append(n)
            continue
        payments[rid] = {"PaymentID": rid, "InvoiceID": iid, "PaymentDate": when.isoformat(), "AmountCents": amount}
    paid = defaultdict(int)
    after_cutoff = []
    for r in payments.values():
        if iso_date(r["PaymentDate"]) <= AS_OF:
            paid[r["InvoiceID"]] += r["AmountCents"]
        else:
            after_cutoff.append(r)
    aging_rows = []
    for inv in invoices.values():
        if iso_date(inv["InvoiceDate"]) > AS_OF:
            continue
        record = dict(inv)
        record["PaidCents"] = paid[inv["InvoiceID"]]
        record["BalanceCents"] = inv["InvoiceAmountCents"] - record["PaidCents"]
        record["DaysPastDue"] = max(0, (AS_OF - iso_date(inv["DueDate"])).days)
        record["AgingBucket"] = aging(record["DaysPastDue"])
        aging_rows.append(record)
    return {"raw": raw, "customers": customers, "products": products, "invoices": invoices,
            "sales": sales, "payments": payments, "aging": aging_rows, "rejected": dict(rejected), "after_cutoff": after_cutoff}


def sql_database(package, raw):
    db = sqlite3.connect(":memory:")
    db.row_factory = sqlite3.Row
    for name, records in raw.items():
        columns = list(records[0])
        db.execute(f'CREATE TABLE raw_{name} (SourceRow INTEGER, ' + ','.join(f'"{c}" TEXT' for c in columns) + ')')
        db.executemany(f'INSERT INTO raw_{name} VALUES (' + ','.join('?' for _ in range(len(columns)+1)) + ')',
                       [[i] + [r[c] for c in columns] for i,r in enumerate(records,2)])
    for name in ["01_clean_validate.sql", "02_reporting_views.sql"]:
        db.executescript((package / "sql" / name).read_text())
    return db


def table_records(db, table):
    return [dict(r) for r in db.execute(f'SELECT * FROM "{table}"')]


def assert_records(name, expected, actual, id_fields, fields=None):
    if fields is None:
        fields = list(expected[0])
    def mapping(rs):
        return {tuple(r[f] for f in id_fields): {f:r[f] for f in fields} for r in rs}
    exp, act = mapping(expected), mapping(actual)
    check(name, exp == act and len(expected) == len(exp) and len(actual) == len(act), {"expected_rows":len(expected), "actual_rows":len(actual),
                            "different_keys": [str(k) for k in set(exp)|set(act) if exp.get(k) != act.get(k)][:5]})


def audit(package):
    helper_tests()
    data = reconstruct(package)
    db = sql_database(package, data["raw"])
    inv, sales, payments, balances = list(data["invoices"].values()), list(data["sales"].values()), list(data["payments"].values()), data["aging"]
    assert_records("Every accepted invoice matches independent parsing", inv, table_records(db,"Invoices"), ["InvoiceID"])
    assert_records("Every accepted sales line matches independent parsing", sales, table_records(db,"SalesLines"), ["LineID"], ["LineID","InvoiceID","ProductID","Units","UnitPriceCents","UnitCostCents"])
    assert_records("Every accepted payment matches independent parsing", payments, table_records(db,"Payments"), ["PaymentID"])
    check("Nine deliberate source records quarantined", len(table_records(db,"Quarantine")) == 9)
    check("All three source types reject exactly three records", Counter(r["SourceTable"] for r in table_records(db,"Quarantine")) == {"Invoices":3,"SalesLines":3,"Payments":3})
    for r in sales:
        r["Date"] = r["InvoiceDate"]
        r["Year"] = int(r["Date"][:4])
        r["YearMonth"] = r["Date"][:7]
    assert_records("Every enriched sales row preserves integer-cent arithmetic", sales, table_records(db,"Sales"), ["LineID"], ["LineID","InvoiceID","Date","CustomerID","ProductID","Channel","Units","RevenueCents","COGSCents","GrossProfitCents"])
    for r in balances:
        r["OutstandingCents"] = r["BalanceCents"]
        r["PaidToDateCents"] = r["PaidCents"]
    assert_records("Every invoice balance and aging bucket matches independent cutoff calculation", balances, table_records(db,"InvoiceBalances"), ["InvoiceID"], ["InvoiceID","InvoiceAmountCents","PaidToDateCents","OutstandingCents","DaysPastDue","AgingBucket"])
    open_rows = [r for r in balances if r["BalanceCents"] > 0]
    assert_records("Receivables contains only open invoices without duplicate balances", open_rows, table_records(db,"Receivables"), ["InvoiceID"], ["InvoiceID","OutstandingCents","DaysPastDue","AgingBucket"])
    check("All eight boundary fixtures are actually present and open", all(any(r["DaysPastDue"]==d for r in open_rows) for d in [0,1,30,31,60,61,90,91]))
    check("Partial-payment invoices are present", any(0<r["PaidCents"]<r["InvoiceAmountCents"] for r in balances))
    check("Exact-cutoff payments are included", any(r["PaymentDate"]==AS_OF.isoformat() for r in payments))
    check("After-cutoff payment records are present and excluded", len(data["after_cutoff"]) > 0 and sum(r["PaidCents"] for r in balances) == sum(r["AmountCents"] for r in payments if iso_date(r["PaymentDate"]) <= AS_OF))
    check("Invoice balance identity holds exactly in integer cents", sum(r["InvoiceAmountCents"] for r in balances) == sum(r["PaidCents"]+r["BalanceCents"] for r in balances))
    check("No overpaid invoice hidden in open-only report", all(r["BalanceCents"]>=0 for r in balances))
    measures = ["Units","RevenueCents","COGSCents","GrossProfitCents"]
    for table, groups in [("MonthlyPerformance",["YearMonth"]),("ChannelPerformance",["Year","Channel"]),("ProductPerformance",["Year","ProductID"]),("CustomerPerformance",["Year","CustomerID"])]:
        grouped = sum_by(sales,groups,measures if table != "CustomerPerformance" else measures[1:])
        expected = [{**dict(zip(groups,k)),**v} for k,v in grouped.items()]
        assert_records(f"Every {table} group matches independent raw reconstruction", expected, table_records(db,table), groups)
    months = sorted({r["YearMonth"] for r in sales})
    check("Complete comparable 24-month history", months == [f"{y}-{m:02d}" for y in [2024,2025] for m in range(1,13)])
    grouped = sum_by(open_rows,["AgingBucket"],["OutstandingCents"])
    assert_records("Every aging bucket total reconciles", [{"AgingBucket":k[0],**v} for k,v in grouped.items()], table_records(db,"AgingSummary"), ["AgingBucket"])
    expected_customers=[]
    for cid in sorted({r["CustomerID"] for r in open_rows}):
        group=[r for r in open_rows if r["CustomerID"]==cid]
        expected_customers.append({"CustomerID":cid,"OpenInvoiceCount":len(group),"OutstandingCents":sum(r["BalanceCents"] for r in group),"OverdueCents":sum(r["BalanceCents"] for r in group if r["DaysPastDue"]>0),"Over90Cents":sum(r["BalanceCents"] for r in group if r["DaysPastDue"]>90),"OldestDaysPastDue":max(r["DaysPastDue"] for r in group)})
    assert_records("Every customer collection priority reconciles", expected_customers,table_records(db,"CustomerReceivables"),["CustomerID"])
    expected_bridge=[]
    for channel, product in sorted({(r["Channel"],r["ProductID"]) for r in sales}):
        a=[r for r in sales if r["Channel"]==channel and r["ProductID"]==product and r["Year"]==2024]
        b=[r for r in sales if r["Channel"]==channel and r["ProductID"]==product and r["Year"]==2025]
        u0,u1=sum(r["Units"] for r in a),sum(r["Units"] for r in b)
        p0,p1=sum(r["RevenueCents"] for r in a)/u0,sum(r["RevenueCents"] for r in b)/u1
        c0,c1=sum(r["COGSCents"] for r in a)/u0,sum(r["COGSCents"] for r in b)/u1
        expected_bridge.append({"Channel":channel,"ProductID":product,"VolumeMixImpactCents":(u1-u0)*(p0-c0),"PriceImpactCents":u1*(p1-p0),"UnitCostImpactCents":-u1*(c1-c0)})
    actual_bridge={(r["Channel"],r["ProductID"]):r for r in table_records(db,"MarginBridge")}
    check("Every price/cost/volume bridge cell reconciles", all(abs(r[f]-actual_bridge[(r["Channel"],r["ProductID"])][f])<0.0001 for r in expected_bridge for f in ["VolumeMixImpactCents","PriceImpactCents","UnitCostImpactCents"]))
    gp_delta=sum(r["GrossProfitCents"]*(1 if r["Year"]==2025 else -1) for r in sales)
    check("Margin bridge explains the full gross-profit movement", abs(sum(r[f] for r in expected_bridge for f in ["VolumeMixImpactCents","PriceImpactCents","UnitCostImpactCents"])-gp_delta)<0.001)
    mutation_tests(package,data)
    metrics={str(y):{f:sum(r[f] for r in sales if r["Year"]==y)/100 for f in ["RevenueCents","COGSCents","GrossProfitCents"]} for y in [2024,2025]}
    metrics["receivables"]={"outstanding":sum(r["BalanceCents"] for r in open_rows)/100,"overdue":sum(r["BalanceCents"] for r in open_rows if r["DaysPastDue"]>0)/100,"over90":sum(r["BalanceCents"] for r in open_rows if r["DaysPastDue"]>90)/100,"open_invoices":len(open_rows)}
    audit_exports(package,db,data,metrics)
    return metrics


def audit_exports(package,db,data,independent):
    mapping = {
        "accepted_invoices":"Invoices", "accepted_sales_lines":"SalesLines", "accepted_payments":"Payments",
        "accepted_customers":"Customers", "accepted_products":"Products", "quarantine":"Quarantine",
        "reporting_sales_cents":"Sales", "reporting_invoice_balances_cents":"InvoiceBalances",
        "reporting_receivables_cents":"Receivables", "reporting_monthly_cents":"MonthlyPerformance",
        "reporting_channels_cents":"ChannelPerformance", "reporting_products_cents":"ProductPerformance",
        "reporting_customers_cents":"CustomerPerformance", "reporting_aging_cents":"AgingSummary",
        "reporting_customer_receivables_cents":"CustomerReceivables", "reporting_margin_bridge_cents":"MarginBridge"}
    def canon(records):
        return sorted(tuple(sorted((k,str(v)) for k,v in r.items())) for r in records)
    for filename,table in mapping.items():
        check(f"Packaged {filename}.csv matches validated rows", canon(rows(package/"outputs"/(filename+".csv"))) == canon(table_records(db,table)))
    model=json.loads((package/"outputs/model_data.json").read_text())
    tables=model["tables"]
    expected=[]
    for r in data["sales"].values():
        expected.append({f:r[f] for f in ["LineID","InvoiceID","Date","CustomerID","ProductID","Channel","Units"]} | {f:r[f+"Cents"]/100 for f in ["Revenue","COGS","GrossProfit"]})
    assert_records("Power BI sales import: every exported dollar amount reconciles",expected,tables["Sales"],["LineID"])
    expected=[]
    for r in data["aging"]:
        if r["BalanceCents"]>0:
            expected.append({"InvoiceID":r["InvoiceID"],"CustomerID":r["CustomerID"],"Channel":r["Channel"],"Outstanding":r["BalanceCents"]/100,"PaidToDate":r["PaidCents"]/100,"InvoiceAmount":r["InvoiceAmountCents"]/100,"DaysPastDue":r["DaysPastDue"],"AgingBucket":r["AgingBucket"]})
    assert_records("Power BI receivables import: every balance and aging value reconciles",expected,tables["Receivables"],["InvoiceID"])
    dates=[(date(2024,1,1)+timedelta(days=i)).isoformat() for i in range(731)]
    check("Power BI date dimension complete including leap day",[r["Date"] for r in tables["Calendar"]]==dates)
    check("Power BI dimension keys unique and all fact foreign keys present", all(len(tables[t])==len({r[f] for r in tables[t]}) for t,f in [("Customers","CustomerID"),("Products","ProductID"),("Channels","Channel"),("Calendar","Date")]) and all(all(r[f] in {d[f] for d in tables[t]} for r in tables["Sales"]) for t,f in [("Customers","CustomerID"),("Products","ProductID"),("Channels","Channel"),("Calendar","Date")]))
    metrics=json.loads((package/"outputs/metrics.json").read_text())
    for year in [2024,2025]:
        annual=next(r for r in metrics["annual"] if r["Year"]==year)
        check(f"Report FY{year} revenue/COGS/profit/margin reconcile",all(abs(annual[f]-independent[str(year)][f+"Cents"])<0.005 for f in ["Revenue","COGS","GrossProfit"]) and abs(annual["GrossMargin"]-annual["GrossProfit"]/annual["Revenue"])<1e-12)
    ar=metrics["receivables"]
    check("Report receivables headline and overdue ratios reconcile", all(abs(ar[k]-independent["receivables"][f])<0.005 for k,f in [("Outstanding","outstanding"),("Overdue","overdue"),("Over90","over90"),("OpenInvoiceCount","open_invoices")]) and abs(ar["OverdueShare"]-ar["Overdue"]/ar["Outstanding"])<1e-12)
    k=metrics["kpis"]; y0,y1=metrics["annual"]
    check("Report comparable year growth and margin percentage points reconcile", abs(k["RevenueGrowth"]-(y1["Revenue"]/y0["Revenue"]-1))<1e-12 and abs(k["GrossProfitGrowth"]-(y1["GrossProfit"]/y0["GrossProfit"]-1))<1e-12 and abs(k["GrossMarginChangePP"]-(y1["GrossMargin"]-y0["GrossMargin"])*100)<1e-12)
    check("Report metric periods and snapshot are explicit",metrics["metadata"]["snapshot_date"]==AS_OF.isoformat() and metrics["metadata"]["report_year"]==2025 and metrics["metadata"]["prior_year"]==2024)
    for channel in ["Wholesale","Direct","Marketplace"]:
        for customer in data["customers"]:
            raw=[r for r in data["sales"].values() if r["Channel"]==channel and r["CustomerID"]==customer and r["Year"]==2025]
            imported=[r for r in tables["Sales"] if r["Channel"]==channel and r["CustomerID"]==customer and r["Date"].startswith("2025")]
            check(f"Customer/channel import filter: {customer}/{channel}",sum(r["RevenueCents"] for r in raw)==sum(round(r["Revenue"]*100) for r in imported))


def mutation_tests(package,data):
    for value,label in [("","blank"),("10oops","mixed alphanumeric"),("1.5","decimal"),("-1","negative")]:
        raw=copy.deepcopy(data["raw"])
        rid=key(raw["payments"][0]["PaymentID"])
        raw["payments"][0]["AmountCents"]=value
        db=sql_database(package,raw)
        check(f"SQL mutation: {label} payment quarantined instead of coerced to zero", db.execute("SELECT COUNT(*) FROM Payments WHERE PaymentID=?",(rid,)).fetchone()[0]==0)
    raw=copy.deepcopy(data["raw"])
    first=copy.deepcopy(raw["payments"][0]); rid=key(first["PaymentID"])
    raw["payments"][0]["AmountCents"]="bad"
    raw["payments"].append(first)
    db=sql_database(package,raw)
    check("SQL mutation: invalid first duplicate retains source-order governance",db.execute("SELECT COUNT(*) FROM Payments WHERE PaymentID=?",(rid,)).fetchone()[0]==0)
    raw=copy.deepcopy(data["raw"])
    rid=key(raw["sales_lines"][0]["LineID"])
    raw["sales_lines"][0]["UnitCostCents"]="0"
    db=sql_database(package,raw)
    result=db.execute("SELECT UnitCostCents FROM SalesLines WHERE LineID=?",(rid,)).fetchone()
    check("SQL mutation: legitimate zero unit cost remains valid",result is not None and result[0]==0)
    raw=copy.deepcopy(data["raw"])
    invoice=key(raw["invoices"][0]["InvoiceID"])
    raw["invoices"][0]["InvoiceDate"]="2025-02-30"
    db=sql_database(package,raw)
    check("SQL mutation: rejected invoice removes child sales and payments", all(db.execute(f"SELECT COUNT(*) FROM {t} WHERE InvoiceID=?",(invoice,)).fetchone()[0]==0 for t in ["Invoices","SalesLines","Payments"]))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("package", type=Path, nargs="?", default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("independent_audit.json"))
    args = parser.parse_args()
    result = {"scope":"Independent standard-library reconstruction from raw CSV, SQL regression tests and report reconciliations", "native_power_bi_tested":False}
    try:
        result["independent_metrics"] = audit(args.package.resolve())
        result["passed"] = True
    except Exception as exc:
        result["passed"] = False
        result["error"] = str(exc)
        raise
    finally:
        result["checks"] = CHECKS
        result["check_count"] = len(CHECKS)
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps(result,indent=2)+"\n")
    print(f"Independent audit: {len(CHECKS)} checks passed")
