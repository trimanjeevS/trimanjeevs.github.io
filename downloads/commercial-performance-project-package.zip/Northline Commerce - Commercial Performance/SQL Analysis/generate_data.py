"""Reproduce fictional source records. Python standard library only; fixed seed."""
from pathlib import Path
import calendar, csv, random
from datetime import date, timedelta

ROOT = Path(__file__).resolve().parent
SEED = 42175

def generate():
    rng = random.Random(SEED)
    customers = [
        ('C001','Alderfield Supply'),('C002','Birchwater Trading'),('C003','Cedarstone Retail'),
        ('C004','Driftwood Merchants'),('C005','Elmbridge Stores'),('C006','Foxglade Supply'),
        ('C007','Graniteleaf Goods'),('C008','Hearthwell Retail'),('C009','Ivydale Traders'),
        ('C010','Juniperlane Supply'),('C011','Kestrelbrook Goods'),('C012','Larchfield Stores'),
        ('C013','Meadowspire Market'),('C014','Northfern Goods'),('C015','Oakharbour Retail'),
        ('C016','Pinegrove Market'),('C017','Quarryvale Goods'),('C018','Riverbend Outlet'),
        ('C019','Sprucehaven Home'),('C020','Thistlebrook Living'),('C021','Uplandfern Goods'),
        ('C022','Valleycrest Home'),('C023','Willowmere Living'),('C024','Yarrowfield Market')]
    products = [
        ('P01','Desk Organizer','Office',2400,1250),('P02','Task Lamp','Office',5800,3000),
        ('P03','Laptop Stand','Office',4600,2200),('P04','Desk Mat','Office',3200,1500),
        ('P05','Storage Basket','Home',2800,1400),('P06','Shelf Organizer','Home',6400,3350),
        ('P07','Utility Cart','Home',14500,7900),('P08','Entryway Rack','Home',9800,5200),
        ('P09','Insulated Bottle','Lifestyle',3600,1650),('P10','Travel Tote','Lifestyle',7200,3400),
        ('P11','Lunch Container Set','Lifestyle',4400,2100),('P12','Weekend Bag','Lifestyle',11800,5900)]
    invoices=[]; lines=[]; payments=[]
    def add_invoice(invdate, due, customer, channel, selections, boundary=False):
        iid = f'INV{len(invoices)+1:05d}'
        total=0
        for product, units, price, cost in selections:
            lines.append([f'L{len(lines)+1:06d}',iid,product,units,price,cost])
            total += units*price
        invoices.append([iid,invdate.isoformat(),due.isoformat(),customer,channel,total])
        def pay(when, amt):
            if amt>0: payments.append([f'PAY{len(payments)+1:06d}',iid,when.isoformat(),amt])
        if boundary:
            pay(date(2025,12,31),total//4)
            pay(date(2026,1,2),total//4)
        elif channel != 'Wholesale':
            pay(invdate+timedelta(days=rng.randint(1,5)),total)
        else:
            highrisk=customer in ('C002','C005','C009')
            if invdate.year==2025 and invdate.month>=8 and highrisk:
                pay(invdate+timedelta(days=16),total*3//10)
                pay(date(2026,2,15),total-total*3//10)
            elif invdate.year==2025 and invdate.month>=10 and rng.random()<0.22:
                pay(due,total//2)
                pay(date(2026,2,20),total-total//2)
            else:
                lag=rng.choice([0,0,0,3,7,12,22,38])
                pay(due+timedelta(days=lag),total)
        return iid
    for year in (2024,2025):
        for month in range(1,13):
            for channel,base in [('Wholesale',20),('Marketplace',18),('Direct',18 if year==2024 else 29)]:
                n=base+(4 if month>=10 else 0)+(2 if year==2025 and channel=='Wholesale' else 0)
                for _ in range(n):
                    invdate=date(year,month,rng.randint(1,calendar.monthrange(year,month)[1]))
                    due=invdate+timedelta(days=30 if channel=='Wholesale' else 7)
                    cid=f'C{rng.randint(1,12) if channel=="Wholesale" else rng.randint(13,18) if channel=="Marketplace" else rng.randint(19,24):03d}'
                    picks=[]
                    for p in rng.sample(products,rng.choice([2,3])):
                        units=rng.randint(10,38) if channel=='Wholesale' else rng.randint(1,8)
                        factor=0.88 if channel=='Wholesale' else 0.93 if channel=='Marketplace' else 1.0
                        if year==2025:
                            factor*=0.93 if channel=='Marketplace' else 1.025
                        price=round(p[3]*factor*(1+rng.choice([-.02,0,0,.02])))
                        cost=round(p[4]*(1.045 if year==2025 else 1.0))
                        picks.append((p[0],units,price,cost))
                    add_invoice(invdate,due,cid,channel,picks)
    boundary=[]
    for dpd in (0,1,30,31,60,61,90,91):
        due=date(2025,12,31)-timedelta(days=dpd)
        iid=add_invoice(due-timedelta(days=30),due,'C002','Wholesale',[('P01',20,2200,1300)],True)
        boundary.append((iid,dpd))
    # Normalization is intentional and documented; these are valid source variations.
    for i,row in enumerate(invoices):
        if i%37==0: row[4]=' '+row[4].lower()+' '
        if i%53==0: row[0]=' '+row[0].lower()+' '
    clean_last_payment=list(payments[-1])
    clean_last_line=list(lines[-1])
    clean_last_invoice=list(invoices[-1])
    invoices += [clean_last_invoice,['BADINV_DATE','2025-02-30','2025-03-30','C001','Wholesale',1000],['BADINV_AMOUNT','2025-11-01','2025-12-01','C001','Wholesale','']]
    lines += [clean_last_line,['BADLINE_UNITS','INV00001','P01','oops',2400,1250],['BADLINE_PRODUCT','INV00001','P99',2,2400,1250]]
    payments += [clean_last_payment,['BADPAY_AMOUNT','INV00001','2025-12-31',''],['BADPAY_INVOICE','INV99999','2025-12-31',1000]]
    def write(name,cols,rows):
        path=ROOT/'data'/name
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('w',newline='',encoding='utf-8') as f:
            w=csv.writer(f);w.writerow(cols);w.writerows(rows)
    write('raw_customers.csv',['CustomerID','CustomerName'],customers)
    write('raw_products.csv',['ProductID','ProductName','Category'],[p[:3] for p in products])
    write('raw_invoices.csv',['InvoiceID','InvoiceDate','DueDate','CustomerID','Channel','InvoiceAmountCents'],invoices)
    write('raw_sales_lines.csv',['LineID','InvoiceID','ProductID','Units','UnitPriceCents','UnitCostCents'],lines)
    write('raw_payments.csv',['PaymentID','InvoiceID','PaymentDate','AmountCents'],payments)
    write('aging_boundary_fixtures.csv',['InvoiceID','ExpectedDaysPastDue'],boundary)
    return {'seed':SEED,'boundary_invoices':boundary}

if __name__=='__main__':
    print(generate())
