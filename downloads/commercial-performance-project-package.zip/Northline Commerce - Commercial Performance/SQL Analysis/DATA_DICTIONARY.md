# Data dictionary

All data is fictional. Identifiers are stable keys, not real customer identifiers. Monetary values in the raw CSV files, SQLite database and CSV files named `_cents` are integer CAD cents. The dashboard's `model_data.json` and the report's `metrics.json` use CAD dollars.

## Source tables

| File | Grain / key | Fields |
|---|---|---|
| raw_customers.csv | One customer account / CustomerID | CustomerName is a fictional account name. Direct and Marketplace accounts are aggregate groupings. |
| raw_products.csv | One product / ProductID | ProductName and Category; categories are Office, Home and Lifestyle. |
| raw_invoices.csv | One source invoice row / InvoiceID after duplicate review | InvoiceDate, DueDate, CustomerID, Channel, InvoiceAmountCents. |
| raw_sales_lines.csv | One source merchandise line / LineID after duplicate review | InvoiceID, ProductID, Units, UnitPriceCents, UnitCostCents. Revenue is Units × UnitPriceCents. |
| raw_payments.csv | One source receipt row / PaymentID after duplicate review | InvoiceID, PaymentDate, AmountCents. Receipts can be partial and can occur after the reporting cutoff. |
| aging_boundary_fixtures.csv | One deliberately constructed boundary invoice / InvoiceID | ExpectedDaysPastDue is the expected aging result at 31 December 2025. |

`SourceRow` in the database is the original one-based CSV row number, including the header. Review tables contain normalized fields, `rn` for duplicate sequence and a nullable `RejectionReason`. A null reason means the row passes the applicable checks. `Quarantine` consolidates rejected invoice, line and payment records with the source table, row number, record ID and reason.

## Dashboard model tables

| Table | Grain / key | Definitions |
|---|---|---|
| Sales | Accepted invoice line / LineID | InvoiceID links the source invoice; Date is InvoiceDate, not payment date. CustomerID, ProductID and Channel link dimensions. Units are invoiced units. Revenue is merchandise line revenue in dollars. COGS is merchandise line cost. GrossProfit = Revenue − COGS. |
| Receivables | Open invoice at one fixed snapshot / InvoiceID | SnapshotDate is 2025-12-31. InvoiceDate and DueDate are original dates. InvoiceAmount is full invoice revenue. PaidToDate includes only accepted receipts dated on or before SnapshotDate. Outstanding = InvoiceAmount − PaidToDate and is positive in this table. CustomerID and Channel link dimensions. |
| Customers | Customer / CustomerID | CustomerName is the account display name. |
| Products | Product / ProductID | ProductName is the product display name; Category is the product category. |
| Channels | Channel / Channel | Wholesale, Marketplace and Direct. |
| Calendar | Calendar day / Date | Every day from 2024-01-01 to 2025-12-31, including leap day: 731 records. Year and MonthNumber are integers; Month is a three-letter display label; YearMonth is YYYY-MM. |

Receivables `DaysPastDue` is `max(SnapshotDate − DueDate, 0)` in whole calendar days. `AgingSort` provides a numeric sort order for `AgingBucket`:

| AgingSort | AgingBucket | DaysPastDue |
|---:|---|---:|
| 0 | Current | 0 |
| 1 | 1-30 days | 1–30 |
| 2 | 31-60 days | 31–60 |
| 3 | 61-90 days | 61–90 |
| 4 | 91+ days | 91 or more |

## Metric definitions

| Metric | Definition |
|---|---|
| Gross margin | Sum of gross profit ÷ sum of revenue. Ratios are recomputed from totals, never averaged across rows. |
| Revenue growth | 2025 revenue ÷ 2024 revenue − 1. |
| Gross-profit growth | 2025 gross profit ÷ 2024 gross profit − 1. |
| Gross-margin change | (2025 gross margin − 2024 gross margin) × 100, expressed in percentage points. |
| Revenue contribution | Group revenue ÷ total same-year revenue. |
| Open receivables | Sum of positive invoice balances at the fixed snapshot. |
| Overdue receivables | Open balances with DaysPastDue > 0. |
| Overdue share | Overdue receivables ÷ open receivables. |
| Over90 / Over90Share | Compatibility field names in metrics: balances with DaysPastDue > 90, and those balances ÷ open receivables. Displayed as 91+ days. |
| Oldest days past due | Maximum DaysPastDue among the group's open invoices. |
| Overdue contribution | Customer overdue balance ÷ total overdue balance. |

The source ledger does not include fees, taxes, returns or provisions. Consequently gross profit is not net profit, an overdue balance is not automatically a bad debt, and the fixed snapshot cannot establish historical DSO or collection performance. The separate report describes proposed management actions, not realized savings.
