# Reproducible R analysis

Prepared by Trimanjeev Sawhney. This folder reproduces the default January 2021 to December 2025 portfolio analysis using base R and the supplied monthly data.

| File | Purpose |
| --- | --- |
| `analysis.R` | Portfolio accounting, performance, risk, allocation drift and validation calculations. |
| `data/monthly_returns.csv` | Sixty monthly NAV total-return observations for IVV, IEFA, AGG and IAU, stored as decimal returns. |
| `data/source_manifest.json` | Provider links, extraction details and original download checksums. Original downloads are not included. |
| `results/analysis_results.json` | Generated statistics and monthly portfolio paths. |
| `results/validation.txt` | Generated validation results. |

From this folder, run `Rscript analysis.R`. In RStudio, set the working directory to this folder and run `source("analysis.R")`. No additional packages or network connection are required once R is installed. Running the script replaces the two generated result files.

The supplied analysis uses a $100,000 starting value and quarterly resets to 40% IVV / 20% IEFA / 30% AGG / 10% IAU, compared with 60% IVV / 40% AGG. Holdings drift between resets. Returns are in USD, reinvest distributions and reflect fund expenses; taxes and trading costs are excluded. Monthly drawdown does not capture intramonth lows.

The script reproduces the supplied default research case. It does **not** regenerate or automatically synchronize the Excel workbook or PDF in the parent folder. Any modifications require corresponding updates and checks across the analysis, workbook and report before the files are shared together.
