# Portfolio performance and risk analysis
# Prepared by Trimanjeev Sawhney. Base R only; no packages or network required.
# Run: Rscript analysis.R [project_directory]
# Returns are decimals. All wealth and P&L are in USD.

args <- commandArgs(trailingOnly = TRUE)
script_arg <- grep('^--file=', commandArgs(), value = TRUE)
script_path <- if (length(script_arg)) gsub('~+~', ' ', sub('^--file=', '', script_arg[1]), fixed = TRUE) else ''
base_dir <- if (length(args)) normalizePath(args[1]) else if (nzchar(script_path)) dirname(normalizePath(script_path)) else getwd()
raw <- read.csv(file.path(base_dir, 'data', 'monthly_returns.csv'), check.names = FALSE)
tickers <- c('IVV', 'IEFA', 'AGG', 'IAU')
dates <- as.Date(raw$date)
returns <- as.matrix(raw[tickers])
expected <- seq(as.Date('2021-02-01'), as.Date('2026-01-01'), by = 'month') - 1
stopifnot(identical(dates, expected), !anyDuplicated(dates), nrow(returns) == 60L,
          is.numeric(returns), all(is.finite(returns)), all(returns > -1))

simulate <- function(r, weights, initial = 100000, rebalance = 3L) {
  stopifnot(is.matrix(r), all(is.finite(r)), all(r > -1), length(weights) == ncol(r),
            all(is.finite(weights)), all(weights >= 0), abs(sum(weights) - 1) < 1e-10,
            length(initial) == 1, is.finite(initial), initial > 0,
            length(rebalance) == 1, rebalance %in% c(1L, 3L, 6L, 12L))
  n <- nrow(r); k <- ncol(r)
  opening <- closing <- pnl <- matrix(0, n, k)
  wealth <- total_return <- turnover <- numeric(n)
  previous <- weights * initial
  for (i in seq_len(n)) {
    before <- sum(previous)
    opening[i, ] <- if ((i - 1L) %% rebalance == 0L) weights * before else previous
    turnover[i] <- if (i == 1L) 0 else sum(abs(opening[i, ] - previous)) / (2 * before)
    pnl[i, ] <- opening[i, ] * r[i, ]
    closing[i, ] <- opening[i, ] + pnl[i, ]
    wealth[i] <- sum(closing[i, ])
    total_return[i] <- wealth[i] / before - 1
    previous <- closing[i, ]
  }
  peak <- cummax(c(initial, wealth))[-1]
  dd <- wealth / peak - 1
  list(opening = opening, closing = closing, pnl = pnl, wealth = wealth,
       returns = total_return, drawdown = dd, turnover = turnover)
}

metric <- function(s, initial = 100000) {
  c(total_return = tail(s$wealth, 1) / initial - 1,
    cagr = (tail(s$wealth, 1) / initial)^(12 / length(s$returns)) - 1,
    volatility = sd(s$returns) * sqrt(12), max_drawdown = min(c(0, s$drawdown)),
    best_month = max(s$returns), worst_month = min(s$returns),
    ending_value = tail(s$wealth, 1), positive_months = sum(s$returns > 0))
}

drawdown_period <- function(s) {
  trough <- which.min(s$drawdown)
  w <- c(100000, s$wealth); ds <- c(as.Date('2020-12-31'), dates)
  peak <- which.max(w[seq_len(trough)])
  after <- which(seq_along(w) > trough + 1L & w >= w[peak])
  list(peak = as.character(ds[peak]), trough = as.character(dates[trough]),
       recovery = if (length(after)) as.character(ds[after[1]]) else 'Not recovered')
}

pw <- c(.4, .2, .3, .1); bw <- c(.6, 0, .4, 0)
p <- simulate(returns, pw); b <- simulate(returns, bw)
active <- p$returns - b$returns
contribution <- p$pnl / c(100000, head(p$wealth, -1))
risk_share <- apply(contribution, 2, function(x) cov(x, p$returns) / var(p$returns))
asset_wealth <- apply(1 + returns, 2, cumprod)
asset_metrics <- lapply(seq_along(tickers), function(j) list(ticker = tickers[j],
  total_return = tail(asset_wealth[, j], 1) - 1,
  cagr = tail(asset_wealth[, j], 1)^(1/5) - 1,
  volatility = sd(returns[, j]) * sqrt(12),
  max_drawdown = min(c(0, asset_wealth[, j] / cummax(c(1, asset_wealth[, j]))[-1] - 1)),
  gain_contribution = sum(p$pnl[, j]) / 100000, risk_share = risk_share[j]))
annual <- lapply(2021:2025, function(y) {
  ix <- which(format(dates, '%Y') == as.character(y))
  opening_value <- if (ix[1] == 1L) 100000 else p$wealth[ix[1] - 1L]
  list(year = y, portfolio = prod(1 + p$returns[ix]) - 1,
       benchmark = prod(1 + b$returns[ix]) - 1,
       assets = apply(1 + returns[ix, , drop = FALSE], 2, prod) - 1,
       contribution = colSums(p$pnl[ix, , drop = FALSE]) / opening_value)
})
end_weights <- p$closing[60, ] / p$wealth[60]
trade <- pw * p$wealth[60] - p$closing[60, ]
results <- list(
  portfolio = as.list(metric(p)), benchmark = as.list(metric(b)),
  tracking_error = sd(active) * sqrt(12),
  cagr_spread = metric(p)['cagr'] - metric(b)['cagr'],
  information_ratio = mean(active) * 12 / (sd(active) * sqrt(12)),
  correlation = cor(returns), covariance = cov(returns),
  correlation_2022 = cor(returns[13:24, ]), asset_metrics = asset_metrics,
  annual = annual, end_weights = end_weights, trades = trade,
  one_way_rebalance = sum(abs(trade)) / (2 * p$wealth[60]),
  initial_hhi = sum(pw^2), end_hhi = sum(end_weights^2),
  effective_funds = 1 / sum(end_weights^2),
  drawdown_dates = list(portfolio = drawdown_period(p), benchmark = drawdown_period(b)),
  monthly = list(dates = as.character(dates), portfolio = p, benchmark = b),
  settings = list(portfolio_weights = pw, benchmark_weights = bw, initial_capital = 100000, rebalance_months = 3))

# Reconciliations test monetary and return identities across every month/year.
stopifnot(max(abs(rowSums(p$pnl) - diff(c(100000, p$wealth)))) < 1e-7,
          abs(sum(p$pnl) - (tail(p$wealth, 1) - 100000)) < 1e-7,
          abs(sum(risk_share) - 1) < 1e-10, abs(sum(trade)) < 1e-7,
          max(abs(rowSums(contribution) - p$returns)) < 1e-12,
          all(vapply(annual, function(y) abs(sum(y$contribution) - y$portfolio) < 1e-12, logical(1))))

# Known-answer tests exercise timing, missing data, and zero-weight assets.
fixture <- matrix(c(.1, 0, 0, .1, -.1, 0), nrow = 3, byrow = TRUE)
z <- simulate(fixture, c(.5, .5), 100, 3)
stopifnot(max(abs(z$wealth - c(105, 110, 104.5))) < 1e-10)
z_monthly <- simulate(fixture, c(.5, .5), 100, 1)
stopifnot(max(abs(z_monthly$wealth - c(105, 110.25, 104.7375))) < 1e-10)
z_flat <- simulate(matrix(0, 12, 2), c(1, 0), 100, 3)
stopifnot(all(z_flat$wealth == 100), all(z_flat$drawdown == 0))
expect_error <- function(expr) inherits(tryCatch({force(expr); NULL}, error = function(e) e), 'error')
stopifnot(expect_error(simulate(fixture, c(.6, .6))),
          expect_error(simulate(fixture, c(1.1, -.1))),
          expect_error(simulate(fixture, c(.5, NA))),
          expect_error(simulate(fixture, c(.5, .5), 0)),
          expect_error(simulate(fixture, c(.5, .5), 100, 2)),
          expect_error(simulate(matrix(c(NA, 0), 1), c(.5, .5))))

# Small JSON encoder keeps the project runnable with base R alone.
json <- function(x) {
  if (is.null(x)) return('null')
  if (is.matrix(x)) return(paste0('[', paste(vapply(seq_len(nrow(x)), function(i) json(unname(x[i, ])), ''), collapse = ','), ']'))
  if (is.list(x)) {
    v <- vapply(x, json, '')
    if (!is.null(names(x))) return(paste0('{', paste(paste0(vapply(names(x), json, ''), ':', v), collapse = ','), '}'))
    return(paste0('[', paste(v, collapse = ','), ']'))
  }
  if (length(x) != 1) return(paste0('[', paste(vapply(seq_along(x), function(i) json(x[i]), ''), collapse = ','), ']'))
  if (is.na(x)) return('null')
  if (is.character(x)) return(encodeString(x, quote = '"'))
  if (is.logical(x)) return(if (x) 'true' else 'false')
  format(as.numeric(x), digits = 17, scientific = FALSE, trim = TRUE)
}
dir.create(file.path(base_dir, 'results'), showWarnings = FALSE)
writeLines(json(results), file.path(base_dir, 'results', 'analysis_results.json'))
writeLines(c('All R validations passed.', paste('R version:', getRversion()),
             '60 complete monthly observations across four funds.',
             'Monthly and annual P&L reconciled; risk contributions sum to 100%.',
             'Known-answer timing and invalid-input tests passed.'),
           file.path(base_dir, 'results', 'validation.txt'))
print(round(rbind(Portfolio = metric(p), Benchmark = metric(b)), 6))
cat('Analysis and validation completed. Results saved in results/.\n')
