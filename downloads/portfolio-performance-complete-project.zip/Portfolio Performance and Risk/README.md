# Portfolio Performance & Risk Analysis

Prepared by **Trimanjeev Sawhney**. An independent historical research project comparing an illustrative diversified allocation with a U.S. 60/40 benchmark over January 2021 to December 2025.

## What to share

- **Portfolio Performance - Research Report.pdf**: the three-page presentation of findings, charts, allocation review, methodology and sources. Send or upload this first.
- **Portfolio Performance - Excel Model.xlsx**: a protected six-tab review copy. Start with **Summary**; use **Allocation** to inspect the saved portfolio and benchmark weights, starting capital and rebalancing frequency. Worksheets and workbook structure are protected, so inputs cannot be changed in this review copy.
- **Portfolio Analysis/**: the R analysis, extracted source returns, provenance manifest and reproducible results for a reviewer who wants to inspect the calculations.

The supplied default portfolio is 40% IVV, 20% IEFA, 30% AGG and 10% IAU. The benchmark is 60% IVV and 40% AGG. Both begin with $100,000 and rebalance quarterly, with weights drifting between resets.

## Reproduce the analysis

Install R, open a terminal in `Portfolio Analysis`, and run:

```sh
Rscript analysis.R
```

Alternatively, set RStudio's working directory to that folder and run `source("analysis.R")`. The script uses base R only: no additional packages, network access or account credentials are needed. It regenerates `results/analysis_results.json` and `results/validation.txt`.

**The R script does not regenerate the Excel workbook or PDF.** The protected workbook and report preserve the supplied default research case. You can rerun the R analysis independently; changing its inputs or generated results does not update these snapshots. Before sharing an alternative analysis, prepare matching outputs and revalidate them together. Changes to a downloaded copy do not affect the files on the portfolio website.

## Validation and interpretation

The default results were compared independently between Python and R. The saved workbook was recalculated in LibreOffice, and ten input-change tests passed. The desktop Microsoft Excel application was not tested.

Returns are monthly provider NAV total returns in USD, with distributions reinvested and fund expenses already reflected. Taxes, trading costs, execution differences and CAD conversion are excluded. Maximum drawdown uses month-end values and can understate losses within a month. The retrospective allocation was not optimized; its exposures differ from the benchmark. This is a hypothetical research exercise, not an actual managed portfolio or employer performance record.

The package includes extracted monthly returns and a manifest identifying provider sources and download checksums. Original provider downloads are not included. See the report for findings, calculation conventions and linked sources.
